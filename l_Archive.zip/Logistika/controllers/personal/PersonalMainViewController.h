//
//  PersonalMainViewController.h
//  Logistika
//
//  Created by BoHuang on 4/19/17.
//  Copyright © 2017 BoHuang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MenuViewController.h"


@interface PersonalMainViewController : MenuViewController
@property (weak, nonatomic) IBOutlet UIView *contentView;

@end
