//
//  test.swift
//  Logistika
//
//  Created by BoHuang on 3/7/18.
//  Copyright © 2018 BoHuang. All rights reserved.
//

import Foundation

class test: NSObject {
    var test1:Int = 0;
}
