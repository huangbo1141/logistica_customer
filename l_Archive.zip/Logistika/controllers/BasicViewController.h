//
//  BasicViewController.h
//  Logistika
//
//  Created by BoHuang on 5/11/17.
//  Copyright © 2017 BoHuang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BasicViewController : UIViewController

-(void)orderTracking:(NSString*)trackId;
@end
