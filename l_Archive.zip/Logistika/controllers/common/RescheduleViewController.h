//
//  RescheduleViewController.h
//  Logistika
//
//  Created by BoHuang on 4/27/17.
//  Copyright © 2017 BoHuang. All rights reserved.
//

#import "MenuViewController.h"

@interface RescheduleViewController : MenuViewController

@property (weak, nonatomic) IBOutlet UIView *viewRoot;

@end
