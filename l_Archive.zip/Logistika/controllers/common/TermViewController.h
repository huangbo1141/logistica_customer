//
//  TermControllerViewController.h
//  Logistika
//
//  Created by BoHuang on 6/6/17.
//  Copyright © 2017 BoHuang. All rights reserved.
//

#import "BasicViewController.h"

@interface TermViewController : BasicViewController
@property (weak, nonatomic) IBOutlet UIWebView *webview;
@end
