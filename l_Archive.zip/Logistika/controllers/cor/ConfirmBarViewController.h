//
//  ConfirmBarViewController.h
//  Logistika
//
//  Created by BoHuang on 4/29/17.
//  Copyright © 2017 BoHuang. All rights reserved.
//

#import "BasicViewController.h"
#import "ConfirmBar.h"


@interface ConfirmBarViewController : BasicViewController

@property (weak, nonatomic) IBOutlet ConfirmBar *confirmBar;

@end
