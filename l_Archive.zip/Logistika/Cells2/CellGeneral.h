//
//  CellGeneral.h
//  EFT
//
//  Created by Twinklestar on 12/11/15.
//  Copyright © 2015 Twinklestar. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface CellGeneral : UITableViewCell

@property (weak,nonatomic) IBOutlet UILabel *lbl_content;

@end
