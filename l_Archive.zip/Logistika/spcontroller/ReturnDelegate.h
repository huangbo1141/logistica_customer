//
//  ReturnDelegate.h
//  Logistika
//
//  Created by q on 11/20/17.
//  Copyright © 2017 BoHuang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface ReturnDelegate : NSObject<UITextViewDelegate,UITextFieldDelegate>

@end
