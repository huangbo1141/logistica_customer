//
//  TextFieldWhitePlaceholder.h
//  intuitive
//
//  Created by BoHuang on 4/13/17.
//  Copyright © 2017 BoHuang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TextFieldWhitePlaceholder : UITextField

@end
