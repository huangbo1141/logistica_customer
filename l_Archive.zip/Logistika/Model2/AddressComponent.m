//
//  AddressComponent.m
//  ResignDate
//
//  Created by BoHuang on 5/8/16.
//  Copyright © 2016 Twinklestar. All rights reserved.
//

#import "AddressComponent.h"

@implementation AddressComponent

@end
