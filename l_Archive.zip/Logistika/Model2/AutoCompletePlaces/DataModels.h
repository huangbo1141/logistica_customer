//
//  DataModels.h
//
//  Created by Krunal  on 31/01/15
//  Copyright (c) 2015 __MyCompanyName__. All rights reserved.
//

// Google Palces
#import "Terms.h"
#import "Predictions.h"
#import "MatchedSubstrings.h"
#import "AutomCompletePlaces.h"


