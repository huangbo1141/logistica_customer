//
//  WNAActionType.m
//  Wordpress News App
//
//  Created by BoHuang on 5/25/16.
//  Copyright © 2016 Nikolay Yanev. All rights reserved.
//

#import "WNAActionType.h"

@implementation WNAActionType


@end
