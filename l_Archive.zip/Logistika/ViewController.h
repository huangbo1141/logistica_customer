//
//  ViewController.h
//  Logistika
//
//  Created by BoHuang on 4/18/17.
//  Copyright © 2017 BoHuang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
@interface ViewController : UIViewController

@property (nonatomic, strong) AVPlayer *avplayer;

@property (strong, nonatomic) UIView *movieView;

//@property (strong, nonatomic) IBOutlet UIView *movieView;
//@property (strong, nonatomic) IBOutlet UIView *gradientView;
//@property (strong, nonatomic) IBOutlet UIView *contentView;

@end

