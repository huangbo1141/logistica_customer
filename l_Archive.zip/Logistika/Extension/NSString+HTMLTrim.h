//
//  NSString+NSString_HTMLTrim.h
//  Wordpress News App
//

#import <Foundation/Foundation.h>

@interface NSString (HTMLTrim)

- (NSString *)stringWithTrimmedHTML;

@end
