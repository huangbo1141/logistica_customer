//
//  CustomTextField.h
//  ResignDate
//
//  Created by Twinklestar on 4/14/16.
//  Copyright © 2016 Twinklestar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomTextField : UITextField

@end
