//
//  WNAActivityIndicator.h
//  Wordpress News App
//

#import <UIKit/UIKit.h>
@interface WNAActivityIndicator : UIView

@end
